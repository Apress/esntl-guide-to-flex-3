-- phpMyAdmin SQL Dump
-- version 2.11.4
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Mar 22, 2008 at 02:57 PM
-- Server version: 5.0.45
-- PHP Version: 5.2.5

--
-- Database: `bookdata`
--

-- --------------------------------------------------------

--
-- Table structure for table `stock`
--

CREATE TABLE IF NOT EXISTS `stock` (
  `authorID` varchar(50) NOT NULL,
  `name` varchar(255) default NULL,
  `authorFName` varchar(255) default NULL,
  `authorLName` varchar(50) default NULL,
  `category` varchar(255) default NULL,
  `description` varchar(255) default NULL,
  PRIMARY KEY  (`authorID`)
) TYPE=MyISAM;

--
-- Dumping data for table `stock`
--

INSERT INTO `stock` (`authorID`, `name`, `authorFName`, `authorLName`, `category`, `description`) VALUES
('1', 'The Picasso Code', 'Dan', 'Blue', 'Fiction', 'Cubist paintings reveal a secret society of people who really look like that'),
('10', 'The Complete History of the World', 'David', 'McClutz', 'Nonfiction', 'McClutz gives you the entire history of all civilization is less than 300 pages'),
('2', 'Here with the Wind', 'Margaret', 'Middle', 'Fiction', 'In this edition, nobody in the south really gives a damn'),
('3', 'Harry Potluck and the Chamber of Money', 'J.K.', 'Roughly', 'Fiction', 'Young wizard finds the real pot-of-gold and retires'),
('4', 'No Expectations', 'Chuck', 'Dickens', 'Fiction', 'Dickens finally reveals what he really thinks of people'),
('5', 'Atlas Stretched', 'Ann', 'Rind', 'Fiction', 'Great inventors finally just take the money and run'),
('6', 'Recycling Software', 'Big', 'Gates', 'Nonfiction', 'How to just change the name and interface of the same old software and sell it as new'),
('7', 'Make Tons of Money', 'Donald', 'Rump', 'Nonfiction', 'Rump explains how he became a billionaire while constantly declaring bankruptcy'),
('8', 'How to Win Enemies and Lose Friends', 'Dale', 'Crochety', 'Nonfiction', 'The Ultimate how-to book for people who want to stay loners'),
('9', 'My Lies', 'Swill', 'Clinton', 'Nonfiction', 'This former American president tries to define what a lie is');
